

class Card

    attr_reader :value, :suit, :display
    def initialize(value,suit,display)
        @value = value
        @suit = suit
        @display = display
    end


end